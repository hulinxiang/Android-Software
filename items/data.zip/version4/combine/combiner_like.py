import csv
import random
import json

# 读取user.csv和post.csv文件
with open('../user/user_test_encrypted.csv', 'r') as user_file, open('../post/post.csv', 'r') as post_file:
    user_reader = csv.DictReader(user_file)
    post_reader = csv.DictReader(post_file)

    # 创建一个列表,存储所有user的ID
    user_ids = [user['email'] for user in user_reader]

    # 遍历post.csv文件中的每一行,为每个post随机添加喜欢它的user的ID
    output_data = []
    for post in post_reader:
        num_liked_users = random.randint(0, 10)  # 随机选择喜欢这个post的user数量
        liked_user_ids = random.sample(user_ids, num_liked_users)  # 随机选择喜欢这个post的user的ID
        liked_by_users = ','.join(liked_user_ids)
        post['likeIDs'] = liked_by_users
        output_data.append(post)

# 将处理后的post数据写入一个新的csv文件
with open('post_with_liked_users.csv', 'w', newline='') as output_file:
    fieldnames = output_data[0].keys()
    writer = csv.DictWriter(output_file, fieldnames=fieldnames)
    writer.writeheader()
    writer.writerows(output_data)

# 将处理后的post数据写入JSON文件
with open('post_with_liked_users.json', 'w') as output_file:
    json.dump(output_data, output_file, indent=4)