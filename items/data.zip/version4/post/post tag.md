Apparel
- Bottomwear: Capris, Jeans, Leggings, Shorts, Skirts, Track Pants, Tracksuits, Trousers 
- Dress: Dresses
- Loungewear and Nightwear: Lounge Pants
- Topwear: Jackets, Kurtas, Shirts, Sweaters, Sweatshirts, Tops, Tshirts, Tunics, Waistcoat

Accessories  
- Accessories: Travel Accessory
- Bags: Backpacks, Duffel Bag, Handbags, Laptop Bag, Messenger Bag, Rucksacks, Wallets
- Belts: Belts
- Eyewear: Sunglasses
- Headwear: Caps  
- Shoe Accessories: Shoe Accessories, Shoe Laces
- Socks: Socks
- Watches: Watches
- Water Bottle: Water Bottle

Footwear
- Flip Flops: Flip Flops
- Sandal: Sandals, Sports Sandals 
- Shoes: Casual Shoes, Flats, Formal Shoes, Heels, Sports Shoes

Sporting Goods
- Sports Equipment: Basketballs
- Wristbands: Wristbands

gender的种类有:

1. Men
2. Women
3. Unisex
4. Boys
5. Girls

masterCategory的种类有:

1. Apparel
2. Footwear
3. Accessories
4. Sporting Goods

subCategory的种类有:

1. Topwear
2. Bottomwear
3. Dress
4. Loungewear and Nightwear
5. Shoes
6. Flip Flops
7. Sandal
8. Bags
9. Wallets
10. Belts
11. Watches
12. Eyewear
13. Socks
14. Headwear
15. Shoe Accessories
16. Sports Equipment
17. Sports Accessories
18. Water Bottle

articleType的种类有:

1. Tshirts
2. Shirts
3. Jackets
4. Sweaters
5. Sweatshirts
6. Tops
7. Tunics
8. Kurtas
9. Jeans
10. Trousers
11. Track Pants
12. Shorts
13. Skirts
14. Leggings
15. Capris
16. Dresses
17. Lounge Pants
18. Sports Shoes
19. Casual Shoes
20. Formal Shoes
21. Flats
22. Heels
23. Flip Flops
24. Sports Sandals
25. Sandals
26. Handbags
27. Backpacks
28. Laptop Bag
29. Messenger Bag
30. Rucksacks
31. Travel Accessory
32. Duffel Bag
33. Wallets
34. Belts
35. Watches
36. Sunglasses
37. Socks
38. Caps
39. Shoe Laces
40. Shoe Accessories
41. Wristbands
42. Basketballs
43. Water Bottle

baseColor的种类有:

1. Blue
2. Pink
3. Beige
4. Navy Blue
5. Black
6. White
7. Yellow
8. Green
9. Maroon
10. Grey
11. Red
12. Cream
13. Brown
14. Olive
15. Charcoal
16. Multi
17. Orange
18. Purple
19. Teal
20. Burgundy
21. Khaki
22. Peach
23. Magenta
24. Gold
25. Mauve
26. Mustard
27. Silver
28. Steel
29. Tan

Season的种类有:

1. Summer
2. Fall
3. Winter
4. Spring

usage的种类有:

1. Casual
2. Sports
3. Formal
4. Ethnic
5. Travel
6. Smart Casual
7. NA