import re
from faker import Faker
import random
import json

fake = Faker("en_AU")

def generate_data(num_records):
    data = []
    user_ids = set()  # 用于存储已生成的userID

    while len(data) < num_records:
        user_id = str(random.randint(10000000, 99999999))
        if user_id in user_ids:
            continue  # 如果userID已存在,则重新生成
        user_ids.add(user_id)  # 将新生成的userID添加到集合中

        email = fake.email()
        name = fake.user_name()
        password = fake.password()
        address = fake.address()
        phone = fake.phone_number()

        phone = re.sub(r"\D", "", phone)  # 去除非数字字符
        if len(phone) == 10:  # 如果是固定电话号码,则添加前缀0
            phone = "0" + phone
        phone = "04" + phone[-8:]  # 添加前缀04,并且只保留后8位数字
        phone = re.sub(r"(\d{4})(\d{3})(\d{3})", r"\1 \2 \3", phone)  # 添加空格分隔符

        record = {
            'userID': user_id,
            'email': email,
            'password': password,  # 明文密码字段
            'name': name,
            'address': address,
            'phone': phone
        }
        data.append(record)

    return data

# 生成 2500 条记录
data_list = generate_data(2500)

# 将数据写入 JSON 文件
with open('user_test.json', 'w', encoding='utf-8') as f:
    json.dump(data_list, f, ensure_ascii=False, indent=4)
print("数据已经成功写入 'fake_data.json'")