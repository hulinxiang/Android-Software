import json
import csv
import random

# Load the data from JSON files
with open('user.json', 'r') as file:
    users = json.load(file)

with open('post.json', 'r') as file:
    posts = json.load(file)

# Extract all post IDs
post_ids = [post['postID'] for post in posts]  # Assuming posts have 'postId'

# Create a dictionary to map user IDs to posts
user_posts = {user['userID']: [] for user in users}

# Randomly assign each post to a user
for post_id in post_ids:
    user_id = random.choice(list(user_posts.keys()))
    user_posts[user_id].append(post_id)

# Prepare data for JSON output
output_data = []
for user_id, post_ids in user_posts.items():
    output_data.append({
        "userID": user_id,
        "postIDs": post_ids
    })

# Write the result to a CSV file
with open('userpost.csv', 'w', newline='') as file:
    writer = csv.writer(file)
    writer.writerow(['UserID', 'PostIDs'])
    for user_id, post_ids in user_posts.items():
        writer.writerow([user_id, ','.join(post_ids)])  # Joining post IDs with a comma

# Save as a JSON file
with open('userpost.json', 'w') as file:
    json.dump(output_data, file, indent=4)


print("combine 已完成")
