import csv
from faker import Faker

# 创建一个Faker对象
fake = Faker("en_AU")

# 生成3344条英文乱码描述
garbled_descriptions = []
for i in range(3344):
    # 生成一个随机的英文文本描述
    english_text = fake.text(max_nb_chars=300)

    # 将英文文本描述转换为乱码
    garbled_text = english_text.encode('utf-8').decode('gbk', 'ignore')

    # 将乱码描述添加到列表中
    garbled_descriptions.append(garbled_text)

# 将乱码描述写入CSV文件
with open('descriptions.csv', 'w', newline='', encoding='utf-8-sig') as csvfile:
    writer = csv.writer(csvfile)

    # 在第一行写入"description"
    writer.writerow(["description"])

    # 写入乱码描述
    for description in garbled_descriptions:
        writer.writerow([description])
