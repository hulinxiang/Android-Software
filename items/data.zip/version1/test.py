import re
from faker import Faker
import random
import json
from collections import defaultdict

fake = Faker("en_AU")

def generate_data(num_records):
    data = defaultdict(dict)
    for _ in range(num_records):
        # 创建基础用户数据
        user_id = str(random.randint(10000000, 99999999))
        email = fake.email()
        name = fake.user_name()
        password = fake.password()  # 直接使用明文密码
        # name = fake.name()
        address = fake.address()
        phone = fake.phone_number()

        # 格式化电话号码为澳洲移动电话号码格式
        phone = re.sub(r"\D", "", phone)  # 去除非数字字符
        if len(phone) == 10:  # 如果是固定电话号码，则添加前缀0
            phone = "0" + phone
        phone = "04" + phone[-8:]  # 添加前缀04，并且只保留后8位数字
        phone = re.sub(r"(\d{4})(\d{3})(\d{3})", r"\1 \2 \3", phone)  # 添加空格分隔符

        # 组合数据
        record = {
            'email': email,
            'password': password,  # 明文密码字段
            'name': name,
            'address': address,
            'phone': phone
        }
        data[user_id] = record
    return data

# 生成 2500 条记录
data_dict = generate_data(2500)

# 将数据写入 JSON 文件
with open('test.json', 'w', encoding='utf-8') as f:
    json.dump(data_dict, f, ensure_ascii=False, indent=4)

print("数据已经成功写入 'fake_data.json'")
