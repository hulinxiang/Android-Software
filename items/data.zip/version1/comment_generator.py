import csv
import random
from faker import Faker

# 创建一个Faker对象
fake = Faker()

# 生成3344行虚拟评论数据
num_rows = 3344
rows = []
for i in range(num_rows):
    # 生成0-10条虚拟评论
    num_comments = random.randint(0, 10)
    comments = []
    for j in range(num_comments):
        # 生成一个随机的英文文本评论
        comment = fake.text(max_nb_chars=300)

        # 将评论添加到列表中
        comments.append(comment)

    # 将虚拟评论用"||"分隔，并添加到行数据中
    comment_str = "||".join(comments)
    rows.append([comment_str])

# 将虚拟评论数据写入CSV文件
with open('comments.csv', 'w', newline='', encoding='utf-8-sig') as csvfile:
    writer = csv.writer(csvfile)

    # 在第一行写入"comments"
    writer.writerow(["comment"])

    # 写入虚拟评论数据
    for row in rows:
        writer.writerow(row)
