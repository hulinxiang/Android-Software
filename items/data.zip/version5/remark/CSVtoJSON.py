import csv
import json

def csv_to_json(csv_file_path, json_file_path):
    # 读取CSV
    with open(csv_file_path, encoding='utf-8') as csvf:
        # 创建CSV Reader对象
        csv_reader = csv.DictReader(csvf)
        
        # 转换为字典列表
        data = list(csv_reader)
    
    # 写入JSON文件
    with open(json_file_path, 'w', encoding='utf-8') as jsonf:
        jsonf.write(json.dumps(data, indent=4))
        
# 使用函数
csv_file_path = 'remark.csv'
json_file_path = 'remark.json'
csv_to_json(csv_file_path, json_file_path)
