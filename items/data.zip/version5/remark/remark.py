import csv
import random
import pandas as pd

def generate_comment():
    comments = [
        "This product looks great! I'm definitely interested in buying it.",
        "I've been looking for something like this for a while. I'm ready to make a purchase.",
        "I'm impressed with the features of this product. I'll take one!",
        "I've heard good things about this brand, and I'm excited to try it out for myself.",
        "I'm in need of a new product like this, and I think this one fits the bill perfectly.",
        "I've done my research, and this product seems like the best option for me. I'm ready to buy.",
        "I'm tired of using my old product, and I'm ready to upgrade to this one.",
        "I've read the reviews, and I'm convinced that this product is worth the investment.",
        "I'm looking forward to trying out this product and seeing how it performs.",
        "I've been saving up for a while, and I'm finally ready to make this purchase.",
        "I'm confident that this product will meet my needs and exceed my expectations.",
        "I'm excited to add this product to my collection.",
        "I've used this product before, and I'm ready to buy it again.",
        "I'm ready to take the plunge and make this purchase.",
        "I'm looking forward to experiencing the benefits of this product for myself.",
        "I've been eyeing this product for a while, and I'm finally ready to buy it.",
        "I'm ready to make a purchase and start using this product right away.",
        "I'm confident that this product will be a great addition to my life.",
        "I'm ready to invest in this product and see the results for myself.",
        "I'm excited to join the many satisfied customers who have already purchased this product."
    ]
    return random.choice(comments)

def main():
    # 读取 xlsx 文件
    post_df = pd.read_excel("postID.xlsx")
    user_df = pd.read_excel("userID.xlsx")

    # 将 DataFrame 转换为列表
    post_ids = post_df["postID"].tolist()
    users = user_df["email"].tolist()

    # 打开输出文件
    with open('comments.csv', 'w', newline='', encoding='utf-8') as output_file:
        comment_writer = csv.writer(output_file)

        comment_writer.writerow(['PostID', 'UserEmail', 'Remark'])

        # 遍历帖子 ID 列表
        for post_id in post_ids:
            # 生成实名评论
            user_email = random.choice(users)
            comment = generate_comment()
            comment_writer.writerow([post_id, user_email, comment])

            # 生成匿名评论
            comment = generate_comment()
            comment_writer.writerow([post_id, 'Anonymous User', comment])

if __name__ == '__main__':
    main()
