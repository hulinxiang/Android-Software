import uuid
import csv

# Open (or create) a file called 'post_ids.csv' in write mode
with open('post_ids.csv', 'w', newline='') as file:
    writer = csv.writer(file)

    # Write the header
    writer.writerow(["postID"])

    # Generate 3455 UUIDs and write them to the file
    for _ in range(3455):
        uuid_str = str(uuid.uuid4())
        writer.writerow([uuid_str])
