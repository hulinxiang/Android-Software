import json
import csv
import random

# Load the data from JSON files
with open('../user/user_test_encrypted.json', 'r') as file:
    users = json.load(file)
with open('../post/post.json', 'r') as file:
    posts = json.load(file)

# Extract user IDs and post IDs
user_ids = [user['email'] for user in users]
post_ids = [post['postID'] for post in posts]

# Create a list to store the user-post mappings
user_post_mappings = []

# Shuffle the user IDs
random.shuffle(user_ids)

# Assign each post to a unique user
for i, post_id in enumerate(post_ids):
    user_id = user_ids[i % len(user_ids)]
    user_post_mappings.append({
        "postID": post_id,
        "userID": user_id
    })

# Write the result to a CSV file
with open('userpost.csv', 'w', newline='') as file:
    writer = csv.writer(file)
    writer.writerow(['PostID', 'UserID'])
    for mapping in user_post_mappings:
        writer.writerow([mapping['postID'], mapping['userID']])

# Save as a JSON file
with open('userpost.json', 'w') as file:
    json.dump(user_post_mappings, file, indent=4)

# Count the number of posts for each user
user_post_counts = {}
for mapping in user_post_mappings:
    user_id = mapping['userID']
    if user_id in user_post_counts:
        user_post_counts[user_id] += 1
    else:
        user_post_counts[user_id] = 1

# Check if the total number of posts matches the sum of user post counts
total_posts = len(post_ids)
total_user_posts = sum(user_post_counts.values())

if total_posts == total_user_posts:
    print("已完成将每个post分配给一个user,并生成userpost.csv和userpost.json文件。")
    print("每个user下面的post数量统计正确,与post的总数量一致。")
else:
    print("每个user下面的post数量统计有误,与post的总数量不一致。")