import json
import csv
import random

# Load the data from JSON files
with open('user/user_test_encrypted.json', 'r') as file:
    users = json.load(file)

with open('post/post.json', 'r') as file:
    posts = json.load(file)

# Extract user IDs and post IDs
user_ids = [user['userID'] for user in users]
post_ids = [post['postID'] for post in posts]

# Create a list to store the user-post mappings
user_post_mappings = []

# Assign posts to each user randomly
for user_id in user_ids:
    # Randomly determine the number of posts for the user (0 to 10)
    num_posts = random.randint(0, 10)

    # Ensure num_posts doesn't exceed the available post_ids
    num_posts = min(num_posts, len(post_ids))

    # Randomly select posts for the user
    user_post_ids = random.sample(post_ids, num_posts)

    # Remove the selected posts from the available post_ids
    post_ids = [post_id for post_id in post_ids if post_id not in user_post_ids]

    # Add the user-post mappings
    for post_id in user_post_ids:
        user_post_mappings.append({
            "userID": user_id,
            "postID": post_id
        })

# Count the number of posts for each user
user_post_counts = {}
for mapping in user_post_mappings:
    user_id = mapping['userID']
    if user_id in user_post_counts:
        user_post_counts[user_id] += 1
    else:
        user_post_counts[user_id] = 1

# Write the user-post counts to a CSV file
with open('user_post_counts.csv', 'w', newline='') as file:
    writer = csv.writer(file)
    writer.writerow(['UserID', 'PostCount'])
    for user_id, post_count in user_post_counts.items():
        writer.writerow([user_id, post_count])

# Save the user-post counts as a JSON file
with open('user_post_counts.json', 'w') as file:
    json.dump(user_post_counts, file, indent=4)

print("已完成为每个user随机分配0到10个post,并统计每个userID下的post数量。")
print(f"总共有{len(users)}个user,{len(user_post_mappings)}个post被分配。")