import csv

input_file = 'styles.csv'  # 输入文件名
output_file = 'styles_new.csv'  # 输出文件名

with open(input_file, 'r') as infile, open(output_file, 'w', newline='') as outfile:
    reader = csv.reader(infile)
    writer = csv.writer(outfile)

    # 复制表头
    header = next(reader)
    header.insert(12, 'image_url')
    writer.writerow(header)

    # 逐行处理数据
    for row in reader:
        image_url = "gs://login-register-firebase-94766.appspot.com/{}.jpg".format(row[0])
        row.insert(11, image_url)
        writer.writerow(row)
