import firebase_admin
from firebase_admin import credentials
from firebase_admin import storage

# Fetch the service account key JSON file contents
cred = credentials.Certificate('./login-register-firebase-94766-firebase-adminsdk-8n14c-f540e36edc.json')

# Initialize the app with a service account, granting admin privileges
firebase_admin.initialize_app(cred, {
    'storageBucket': 'gs://login-register-firebase-94766.appspot.com'
})

# Get a reference to the storage service
bucket = storage.bucket()

# Get a reference to the images folder in the bucket
images_ref = bucket.reference('customdata')

import os

# Replace this with the path to your local directory containing the images
local_directory = './imageSet/'

# Get a list of all files in the local directory
local_files = os.listdir(local_directory)

# Iterate over the local files
for local_file in local_files:
    # Get a reference to the Firebase Storage file
    firebase_file = bucket.blob(local_file)

    # Check if the file exists in Firebase Storage
    if firebase_file.exists():
        print(f'{local_file} exists in Firebase Storage')
    else:
        print(f'{local_file} does not exist in Firebase Storage')
