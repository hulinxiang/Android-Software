import csv
import os

# 打开CSV文件
with open('imageSet.csv', 'r') as csv_file:
    # 创建CSV读取器
    csv_reader = csv.reader(csv_file)

    # 遍历CSV文件中的每一行
    for row in csv_reader:
        # 获取文件名
        filename = row[0]

        # 构建完整的文件路径
        filepath = os.path.join('imageSet', filename)

        # 检查文件是否存在
        if not os.path.isfile(filepath):
            print(f'文件{filename}不存在')
        # else:
        #     print(f'文件{filename}不存在')
