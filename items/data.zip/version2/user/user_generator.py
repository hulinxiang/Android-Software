import re
import csv
import hashlib
from faker import Faker
import random
import json

fake = Faker("en_AU")

def generate_data(num_records):
    data = []
    user_ids = set()  # 用于存储已生成的userID

    # 添加第一条固定的用户信息
    fixed_user_id_1 = "19999999"
    fixed_email_1 = "comp6442@anu.edu.au"
    fixed_name_1 = "COMP6442"
    fixed_password_1 = "comp6442"
    fixed_address_1 = "108 North Rd, Acton ACT 2601"
    fixed_phone_1 = "0261 250 290"

    fixed_record_1 = {
        'userID': fixed_user_id_1,
        'email': fixed_email_1,
        'password': fixed_password_1,  # 明文密码字段
        'name': fixed_name_1,
        'address': fixed_address_1,
        'phone': fixed_phone_1
    }
    data.append(fixed_record_1)

    # 添加第二条固定的用户信息
    fixed_user_id_2 = "18888888"
    fixed_email_2 = "comp2100@anu.edu.au"
    fixed_name_2 = "COMP2100"
    fixed_password_2 = "comp2100"
    fixed_address_2 = "ANU Canberra, ACT 2600"
    fixed_phone_2 = "0261 255 111"

    fixed_record_2 = {
        'userID': fixed_user_id_2,
        'email': fixed_email_2,
        'password': fixed_password_2,  # 明文密码字段
        'name': fixed_name_2,
        'address': fixed_address_2,
        'phone': fixed_phone_2
    }
    data.append(fixed_record_2)

    while len(data) < num_records + 2:
        user_id = str(random.randint(20000000, 99999999))
        if user_id in user_ids:
            continue  # 如果userID已存在,则重新生成
        user_ids.add(user_id)  # 将新生成的userID添加到集合中

        email = fake.email()
        name = fake.user_name()
        password = fake.password()
        address = fake.address()
        phone = fake.phone_number()

        phone = re.sub(r"\D", "", phone)  # 去除非数字字符
        if len(phone) == 10:  # 如果是固定电话号码,则添加前缀0
            phone = "0" + phone
        phone = "04" + phone[-8:]  # 添加前缀04,并且只保留后8位数字
        phone = re.sub(r"(\d{4})(\d{3})(\d{3})", r"\1 \2 \3", phone)  # 添加空格分隔符

        record = {
            'userID': user_id,
            'email': email,
            'password': password,  # 明文密码字段
            'name': name,
            'address': address,
            'phone': phone
        }
        data.append(record)

    return data

# 生成 2500 条记录
data_list = generate_data(2500)

# 将未加密数据写入 JSON 文件
with open('user_test_unencrypted.json', 'w', encoding='utf-8') as f:
    json.dump(data_list, f, ensure_ascii=False, indent=4)

# 将未加密数据写入 CSV 文件
with open('user_test_unencrypted.csv', 'w', newline='', encoding='utf-8') as f:
    fieldnames = ['userID', 'email', 'password', 'name', 'address', 'phone']
    writer = csv.DictWriter(f, fieldnames=fieldnames)
    writer.writeheader()
    for row in data_list:
        writer.writerow(row)

# 对密码进行加密
encrypted_data_list = []
for row in data_list:
    password_hash = hashlib.sha256(row['password'].encode('utf-8')).hexdigest()
    encrypted_row = {
        'userID': row['userID'],
        'email': row['email'],
        'password': password_hash,  # 加密后的密码字段
        'name': row['name'],
        'address': row['address'],
        'phone': row['phone']
    }
    encrypted_data_list.append(encrypted_row)

# 将加密数据写入 JSON 文件
with open('user_test_encrypted.json', 'w', encoding='utf-8') as f:
    json.dump(encrypted_data_list, f, ensure_ascii=False, indent=4)

# 将加密数据写入 CSV 文件
with open('user_test_encrypted.csv', 'w', newline='', encoding='utf-8') as f:
    fieldnames = ['userID', 'email', 'password', 'name', 'address', 'phone']
    writer = csv.DictWriter(f, fieldnames=fieldnames)
    writer.writeheader()
    for row in encrypted_data_list:
        writer.writerow(row)

print("数据已经成功写入 'user_test_unencrypted.json', 'user_test_unencrypted.csv', 'user_test_encrypted.json' 和 'user_test_encrypted.csv'")
